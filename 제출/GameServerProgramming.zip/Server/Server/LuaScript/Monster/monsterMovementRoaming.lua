moveable = true;

function Move()
	API_MoveRandomly(myId, 1)
end


