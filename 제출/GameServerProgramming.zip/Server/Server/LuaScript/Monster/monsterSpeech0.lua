
-- speech for Boss
speechOnBattleBegin
speechOnBattleEnd
speechOnChase
speechOnChaseFail
speechOnIdle
speechOnBattleBegin